package com.example.demo.service;

import java.util.List;

import com.example.demo.model.LoginUserModel;

public interface LoginUserService {
	public int count(LoginUserModel loginUser);

	 List<LoginUserModel> getUser();

	public List<LoginUserModel> user(LoginUserModel loginUserModel);
	
	
	
	
		
	
}
