package kk.soft.co.jp.sys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SysApplicationTests {

	@Test
	void contextLoads() {
	}

}
