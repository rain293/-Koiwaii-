package com.example.demo.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ui.Model;

import com.example.demo.model.LoginUserModel;
import com.example.demo.service.LoginUserService;

@ExtendWith(MockitoExtension.class)
public class MainControllerTest {

    @Mock
    private LoginUserService loginUserService;

    @Mock
    private HttpSession httpSession;

    @Mock
    private Model model;

    @InjectMocks
    private MainController mainController;

    private LoginUserModel user1;
    private LoginUserModel user2;
    private LoginUserModel admin;

    @BeforeEach
    void setUp() {
        user1 = new LoginUserModel();
        user1.setId(1);
        user1.setName("Test User");
        user1.setPassword("123456");
        user1.setEmail("test@test.com");
        user1.setVisa("2023-04-30");
        user1.setVisatype("Business");
        user1.setRemaining("90");
        user1.setAddress("123 Street");

        user2 = new LoginUserModel();
        user2.setId(2);
        user2.setName("Another User");
        user2.setPassword("abcdef");
        user2.setEmail("another@test.com");
        user2.setVisa("2023-06-30");
        user2.setVisatype("Tourist");
        user2.setRemaining("60");
        user2.setAddress("456 Street");

        admin = new LoginUserModel();
        admin.setId(3);
        admin.setName("Admin");
        admin.setPassword("admin");
        admin.setEmail("admin@admin");
        admin.setVisa("2023-12-31");
        admin.setVisatype("Business");
        admin.setRemaining("180");
        admin.setAddress("789 Street");
    }

    @Test
    @DisplayName("Test successful login with existing email and password")
    void testSuccessfulLogin() {
        List<LoginUserModel> userList = new ArrayList<>();
        userList.add(admin);
        when(loginUserService.count(admin)).thenReturn(1);
        when(loginUserService.user(admin)).thenReturn(userList);
        when(httpSession.getAttribute("email")).thenReturn(admin.getEmail());

        String viewName = mainController.login(admin, model, httpSession);

        assertEquals("mypage", viewName);
        verify(loginUserService).count(admin);
        verify(loginUserService).user(admin);
        verify(httpSession).setAttribute("email", admin.getEmail());
    }

    @Test
    @DisplayName("Test login failure with admin credentials")
    void testLoginFailureWithAdminCredentials() {
        when(loginUserService.count(user2)).thenReturn(1);

        String viewName = mainController.login(user2, model, httpSession);

        assertEquals("redirect:/user/home", viewName);
        verify(loginUserService).count(user2);
    }
}

/*package com.example.demo.controller;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ui.Model;

import com.example.demo.model.LoginUserModel;
import com.example.demo.service.LoginUserService;

@ExtendWith(MockitoExtension.class)
class MainControllerTest {
    @Mock
    LoginUserService loginUserService;

    @Mock
    Model model;

    @Mock
    HttpSession session;

    @InjectMocks
    MainController mainController;
    
    @Test
    public void testLoginUserWithEmailPasswordInDatabase() {
        // Arrange
        LoginUserModel loginUserModel = new LoginUserModel();
        loginUserModel.setEmail("test@example.com");
        loginUserModel.setPassword("password");

        List<LoginUserModel> expectedUserList = new ArrayList<>();
        expectedUserList.add(loginUserModel);

        LoginUserService mockLoginUserService = Mockito.mock(LoginUserService.class);
        Mockito.when(mockLoginUserService.count(loginUserModel)).thenReturn(1);
        Mockito.when(mockLoginUserService.user(loginUserModel)).thenReturn(expectedUserList);

        HttpSession mockSession = Mockito.mock(HttpSession.class);

        Model mockModel = Mockito.mock(Model.class);

        MainController mainController = new MainController(mockLoginUserService);

        // Act
        String result = mainController.login(loginUserModel, mockModel, mockSession);

        // Assert
        assertEquals("mypage", result);
    }
    @Test
    public void testLoginUserWithAdminEmailAndPassword() {
        // Arrange
        LoginUserModel loginUserModel = new LoginUserModel();
        loginUserModel.setEmail("admin@admin");
        loginUserModel.setPassword("admin");

        LoginUserService mockLoginUserService = Mockito.mock(LoginUserService.class);
        Mockito.when(mockLoginUserService.count(loginUserModel)).thenReturn(1);

        HttpSession mockSession = Mockito.mock(HttpSession.class);

        Model mockModel = Mockito.mock(Model.class);

        MainController mainController = new MainController(mockLoginUserService);

        // Act
        String result = mainController.login(loginUserModel, mockModel, mockSession);

        // Assert
        assertEquals("redirect:/user/home", result);
    }
    @Test
    public void testLoginUserWithEmailPasswordNotInDatabase() {
        // Arrange
        LoginUserModel loginUserModel = new LoginUserModel();
        loginUserModel.setEmail("test@example.com");
        loginUserModel.setPassword("password");

        LoginUserService mockLoginUserService = Mockito.mock(LoginUserService.class);
        Mockito.when(mockLoginUserService.count(loginUserModel)).thenReturn(0);

        HttpSession mockSession = Mockito.mock(HttpSession.class);

        Model mockModel = Mockito.mock(Model.class);

        MainController mainController = new MainController(mockLoginUserService);

        // Act
        String result = mainController.login(loginUserModel, mockModel, mockSession);

        // Assert
        assertEquals("index", result);
    }
}*/
    /*
    List<LoginUserModel> mockUsers = new ArrayList<>();
    LoginUserModel user1 = new LoginUserModel();
    LoginUserModel user2 = new LoginUserModel();
    LoginUserModel user3 = new LoginUserModel();

    @BeforeEach
    void init() {
        user1.setEmail("test1@test.com");
        user1.setPassword("password1");
        mockUsers.add(user1);

        user2.setEmail("test2@test.com");
        user2.setPassword("password2");
        mockUsers.add(user2);

        user3.setEmail("admin@admin");
        user3.setPassword("admin");
        mockUsers.add(user3);
    }

    @Test
    @DisplayName("Test login with correct email and password")
    void testLoginWithCorrectEmailAndPassword() {
        when(loginUserService.count(any(LoginUserModel.class))).thenReturn(1);
        when(loginUserService.user(any(LoginUserModel.class))).thenReturn(mockUsers);

        String result = mainController.login(user1, model, session);

        assertEquals("mypage", result);
        verify(session).setAttribute("email", user1.getEmail());
        verify(model).addAttribute("listuser", mockUsers);
    }
    @Test
    @DisplayName("Test login with admin email and password")
    void testLoginWithAdminEmailAndPassword() {
        when(loginUserService.count(any(LoginUserModel.class))).thenReturn(1);

        String result = mainController.login(user3, model, session);

        assertEquals("redirect:/user/home", result);
    }

    @Test
    @DisplayName("Test login with incorrect email and password")
    void testLoginWithIncorrectEmailAndPassword() {
        when(loginUserService.count(any(LoginUserModel.class))).thenReturn(0);

        String result = mainController.login(new LoginUserModel(), model, session);

        assertEquals("index", result);
        verify(model).addAttribute(eq("error"), anyString());
    }
}*/



/*package com.example.demo.controller;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import com.example.demo.model.LoginUserModel;
import com.example.demo.service.LoginUserService;

@ExtendWith(MockitoExtension.class)
public class MainControllerTest {

    @Mock
    private LoginUserService loginUserService;

    @InjectMocks
    private MainController mainController;

    private MockMvc mockMvc;

    @BeforeEach
    public void setup() {
        mockMvc = MockMvcBuilders.standaloneSetup(mainController).build();
    }
    @Test
    public void testLoginAdmin() throws Exception {
        LoginUserModel loginUserModel = new LoginUserModel();
        loginUserModel.setEmail("admin@admin");
        loginUserModel.setPassword("admin");

        HttpSession session = null;
        Model model = null;
        BindingResult bindingResult = null;

        when(loginUserService.count(loginUserModel)).thenReturn(1);

        mockMvc.perform(post("/user/login").flashAttr("loginUserModel", loginUserModel))
                .andExpect(status().isFound())
                .andExpect(redirectedUrl("/user/home"));
    }
    

}*/


/*package com.example.demo.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ui.Model;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.model.LoginUserModel;
import com.example.demo.service.LoginUserService;

@ExtendWith(MockitoExtension.class)
class MainControllerTest {
    @Mock
    private LoginUserService loginUserService;

    @Mock
    private HttpSession session;

    @Mock
    private Model model;

    @Mock
    private RedirectAttributes redirectAttributes;

    @InjectMocks
    private MainController mainController;

    private List<LoginUserModel> userList;

    @BeforeEach
    void setUp() {
        userList = new ArrayList<>();
        LoginUserModel user1 = new LoginUserModel();
        user1.setEmail("test1@example.com");
        user1.setPassword("password1");
        userList.add(user1);
        LoginUserModel user2 = new LoginUserModel();
        user2.setEmail("admin@admin");
        user2.setPassword("admin");
        userList.add(user2);
    }

    @Test
    void testLoginSuccess() {
        // Arrange
        LoginUserModel loginUserModel = new LoginUserModel();
        loginUserModel.setEmail("test@example.com");
        loginUserModel.setPassword("password");
        when(loginUserService.count(any())).thenReturn(1);
        when(loginUserService.user(any())).thenReturn(userList);

        // Act
        String result = mainController.login(loginUserModel, model, session);

        // Assert
        assertEquals("mypage", result);
    }

    @Test
    void testLoginAdmin() {
        // Arrange
        LoginUserModel loginUserModel = new LoginUserModel();
        loginUserModel.setEmail("admin@admin");
        loginUserModel.setPassword("admin");
        when(loginUserService.count(any())).thenReturn(1);
        when(loginUserService.user(any())).thenReturn(userList);

        // Act
        String result = mainController.login(loginUserModel, model, session);

        // Assert
        assertEquals("redirect:/user/home", result);
    }

    @Test
    void testLoginFailure() {
        // Arrange
        LoginUserModel loginUserModel = new LoginUserModel();
        loginUserModel.setEmail("test1@example.com");
        loginUserModel.setPassword("password1");
        when(loginUserService.count(any())).thenReturn(0);

        // Act
        String result = mainController.login(loginUserModel, model, session);

        // Assert
        assertEquals("index", result);
    }
}*/
