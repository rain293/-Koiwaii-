package com.example.demo.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;

import com.example.demo.model.LoginUserModel;
import com.example.demo.model.NewUserModel;
import com.example.demo.service.LoginUserService;
import com.example.demo.service.NewUserService;
import com.example.demo.service.UserUpdateService;

@ExtendWith(MockitoExtension.class)

public class MainControllerTest2 {

	/*SaveCase*/

	private MockMvc mockMvc;

	@Mock
	private NewUserService newUserService;

	@Mock
	private LoginUserService loginUserService;

	@Mock
	private HttpSession session;

	@Mock
	private UserUpdateService userUpdateService;

	@Mock
	private NewUserModel newUserModel;
	@Mock
	private LoginUserModel loginUserModel;

	@InjectMocks
	private MainController mainController;
	private Model model;

	private MockHttpSession mockSession;

	@BeforeEach
	public void setup() {
		model = mock(Model.class);
		newUserModel = new NewUserModel();
		newUserModel.setEmail("test@example.com");
		newUserModel.setVisa("2023-04-30");

		loginUserModel = new LoginUserModel();
		loginUserModel.setEmail("test@example.com");
		loginUserModel.setPassword("password");
	}

	@Test
	public void testLoginSuccessful1() {
		// setup
		LoginUserModel loginUserModel = new LoginUserModel();
		loginUserModel.setEmail("z@z");
		loginUserModel.setPassword("312");
		Model model = new ExtendedModelMap();
		HttpSession session = new MockHttpSession();

		// execute
		String viewName = mainController.login(loginUserModel, model, session);

		// verify
		assertEquals("mypage", viewName);
		assertEquals("z@z", session.getAttribute("email"));
		List<LoginUserModel> list = (List<LoginUserModel>) model.getAttribute("listuser");
		assertEquals(1, list.size());
		assertEquals(0, model.getAttribute("daysBetween"));
		assertNull(model.getAttribute("error"));
	}

	@Test
	public void testLoginSuccessful() {
		// setup
		LoginUserModel loginUserModel = new LoginUserModel();
		loginUserModel.setEmail("admin@admin");
		loginUserModel.setPassword("admin");
		Model model = new ExtendedModelMap();
		HttpSession session = new MockHttpSession();

		// execute

		String viewName = mainController.login(loginUserModel, model, session);

		// verify
		assertEquals("redirect:/home", viewName);
		assertEquals("admin@admin", session.getAttribute("email"));
		assertNull(model.getAttribute("listuser"));
		assertNull(model.getAttribute("daysBetween"));
		assertNull(model.getAttribute("error"));
	}

	@Test
	public void TestSignup() {
		String result = mainController.signup();
		assertEquals("signup", result);
	}

	@Test
	public void testBacklogin() {
		String result = mainController.backlogin();
		assertEquals("index", result);
	}

	@Test
	public void testEntry_Success() {
		NewUserModel newUserModel = new NewUserModel();
		when(newUserService.search(newUserModel)).thenReturn(0);
		when(newUserService.insert(newUserModel)).thenReturn(1);
		String result = mainController.entry(newUserModel, model);
		assertEquals("index", result);
		verify(model).addAttribute("name", "登録完了");
	}

	@Test
	public void testEntry_Failure() {
		NewUserModel newUserModel = new NewUserModel();
		when(newUserService.search(newUserModel)).thenReturn(1);
		String result = mainController.entry(newUserModel, model);
		assertEquals("signup", result);
		verify(model).addAttribute("id", "既にメールアドレスが登録されています。");
	}

	@Test
	public void testEntry_WithNewEmail() {
	when(newUserService.search(any(NewUserModel.class))).thenReturn(0);
	String result = mainController.entry(newUserModel, model);
	verify(newUserService).insert(any(NewUserModel.class));
	verify(model).addAttribute(eq("name"), eq("登録完了"));
	assertThat(result).isEqualTo("index");
	}

	@Test
	public void testEntry_WithExistingEmail() {
	    when(newUserService.search(any(NewUserModel.class))).thenReturn(1);
	    String result = mainController.entry(newUserModel, model);
	    verify(newUserService, times(2)).search(any(NewUserModel.class));
	    verify(model).addAttribute(eq("id"), eq("既にメールアドレスが登録されています。"));
	    assertThat(result).isEqualTo("signup");
	}

	@Test
	public void testLogin_WithIncorrectCredentials() {
		when(loginUserService.count(any(LoginUserModel.class))).thenReturn(0);
		String result = mainController.login(loginUserModel, model, session);
		verify(loginUserService).count(any(LoginUserModel.class));
		assertThat(result).isEqualTo("index");
	}

	@Test
	public void testLogin_Failure() {
		LoginUserModel loginUserModel = new LoginUserModel();
		when(loginUserService.count(loginUserModel)).thenReturn(0);
		String result = mainController.login(loginUserModel, model, session);
		assertEquals("index", result);
		verify(model).addAttribute("error", "もう一度入力してください");
	}

	@Test
	public void testLogin_Success() {
		LoginUserModel loginUserModel = new LoginUserModel();
		List<LoginUserModel> listuser = new ArrayList<>();
		listuser.add(new LoginUserModel());
		when(loginUserService.count(loginUserModel)).thenReturn(1);
		when(loginUserService.user(loginUserModel)).thenReturn(listuser);
		when(session.getAttribute("email")).thenReturn("test@example.com");
		String result = mainController.login(loginUserModel, model, session);
		assertEquals("mypage", result);
		verify(model).addAttribute("listuser", listuser);
		verify(model).addAttribute("daysBetween", anyLong());
	}

	@Test
	void testLoginSuccess() {
		LoginUserModel loginUserModel = new LoginUserModel(); // Khởi tạo đối tượng loginUserModel
		when(loginUserService.count(loginUserModel)).thenReturn(1);
		when(loginUserService.user(loginUserModel)).thenReturn(null);
		when(session.getAttribute("email")).thenReturn("z@z");
		String result = mainController.login(loginUserModel, model, session);
		assertEquals("mypage", result);
	}

	@Test
	public void testLogin_WithCorrectCredentials() {
	    when(loginUserService.count(eq(loginUserModel))).thenReturn(1);
	    when(loginUserService.user(eq(loginUserModel))).thenReturn(new ArrayList<>());
	
	    String result = mainController.login(loginUserModel, model, session);
	
	    verify(session).setAttribute(eq("email"), eq(loginUserModel.getEmail()));
	    assertThat(result).isEqualTo("mypage");
	}

	@Test
	public void testHome() {
		List<NewUserModel> listuser = new ArrayList<>();
		listuser.add(newUserModel);
		when(newUserService.checkall(any(NewUserModel.class))).thenReturn(listuser);

		String result = mainController.home(model, newUserModel);
		verify(newUserService).checkall(any(NewUserModel.class));
		assertThat(result).isEqualTo("home");
	}

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
		NewUserModel newUserModel = new NewUserModel();
		newUserModel.setId(1);
	}

	@Test
	void testGetDelete() {
		NewUserModel newUserModel = new NewUserModel();
		newUserModel.setId(1);
		// mock the selectupdate method of newUserService
		List<NewUserModel> userList = new ArrayList<>();
		userList.add(newUserModel);
		when(newUserService.selectupdate(newUserModel)).thenReturn(userList);

		// call the getdelete method and check the returned view name and model attribute
		String result = mainController.getdelete(newUserModel.getId(), model, newUserModel);
		assertEquals("delete", result);
		verify(model, times(1)).addAttribute("listuser", userList);
	}

	@Test
	void testDelete() {
		NewUserModel newUserModel = new NewUserModel();
		newUserModel.setId(1);
		// call the delete method and check the returned view name and that the delete method of newUserService was called
		String result = mainController.delete(newUserModel.getId(), newUserModel);
		assertEquals("redirect:/user/home", result);
		verify(newUserService, times(1)).delete(newUserModel);
	}
	/*@Test
	public void testLoginSuccess_Admin() {
	    // Setup
	    LoginUserModel user = new LoginUserModel();
	    user.setEmail("admin@admin");
	  

	    List<LoginUserModel> userList = new ArrayList<>();
	    userList.add(user);

	    LocalDate visaDate = LocalDate.of(2022, 12, 31);
	    user.setVisa(visaDate.toString());

	    when(loginUserService.count(user)).thenReturn(1);
	    when(loginUserService.user(user)).thenReturn(userList);

	    // Exercise
	    String viewName = mainController.login(user, model, session);

	    // Verify
	    assertEquals("redirect:/user/home", viewName);
	}*/
	

}
