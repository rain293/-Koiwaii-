package kk.soft.co.jp.sys.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import kk.soft.co.jp.sys.model.MessageInfoMstModel;

@Repository
@Mapper
public interface MessageInfoMstMapper {

	List<MessageInfoMstModel> selectAll();

	List<MessageInfoMstModel> selectAdmin();

	List<MessageInfoMstModel> selectUser();

	int insert(MessageInfoMstModel messageInfoMstModel);

	MessageInfoMstModel checkEmail(MessageInfoMstModel messageInfoMstModel);

	MessageInfoMstModel checkSignin(MessageInfoMstModel messageInfoMstModel);

	public int delete(MessageInfoMstModel messageInfoMstModel);

	public List<MessageInfoMstModel> back(MessageInfoMstModel messageInfoMstModel);

	public int update(MessageInfoMstModel messageInfoMstModel);

	public List<MessageInfoMstModel> back1(MessageInfoMstModel messageInfoMstModel);

	/*	public int update1(MessageInfoMstModel messageInfoMstModel);
	*/
	List<MessageInfoMstModel> back1(@Param(value = "id") int id);

	int update1(MessageInfoMstModel id);

	List<MessageInfoMstModel> selectEmail(String email);

	List<MessageInfoMstModel> userInfo(MessageInfoMstModel messageInfoMstModel);

}
