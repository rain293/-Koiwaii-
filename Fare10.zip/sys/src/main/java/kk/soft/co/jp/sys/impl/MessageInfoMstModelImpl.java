package kk.soft.co.jp.sys.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import kk.soft.co.jp.sys.mapper.MessageInfoMstMapper;
import kk.soft.co.jp.sys.model.MessageInfoMstModel;
import kk.soft.co.jp.sys.service.MessageInfoMstService;

@Service
public class MessageInfoMstModelImpl implements MessageInfoMstService {

	@Resource
	private MessageInfoMstMapper messageInfoMstmapper;

	@Override
	public Object selectAll() {
		return messageInfoMstmapper.selectAll();
	}

	@Override
	public Object selectAdmin() {
		return messageInfoMstmapper.selectAdmin();
	}

	@Override
	public Object insert(MessageInfoMstModel messageInfoMstModel) {
		return messageInfoMstmapper.insert(messageInfoMstModel);
	}

	@Override
	public MessageInfoMstModel checkEmail(MessageInfoMstModel messageInfoMstModel) {
		return messageInfoMstmapper.checkEmail(messageInfoMstModel);
	}

	@Override
	public MessageInfoMstModel checkSignin(MessageInfoMstModel messageInfoMstModel) {
		return messageInfoMstmapper.checkSignin(messageInfoMstModel);

	}

	@Override
	public int delete(MessageInfoMstModel messageInfoMstModel) {
		return messageInfoMstmapper.delete(messageInfoMstModel);
	}

	@Override
	public List<MessageInfoMstModel> back(MessageInfoMstModel messageInfoMstModel) {
		return messageInfoMstmapper.back(messageInfoMstModel);
	}

	@Override
	public int update(MessageInfoMstModel messageInfoMstModel) {
		return messageInfoMstmapper.update(messageInfoMstModel);
	}

	@Override
	public List<MessageInfoMstModel> back1(MessageInfoMstModel messageInfoMstModel) {
		return messageInfoMstmapper.back1(messageInfoMstModel);
	}

	@Override
	public int update1(MessageInfoMstModel messageInfoMstModel) {
		return messageInfoMstmapper.update1(messageInfoMstModel);
	}

}
