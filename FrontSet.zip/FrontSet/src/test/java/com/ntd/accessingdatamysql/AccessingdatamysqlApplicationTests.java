package com.ntd.accessingdatamysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccessingdatamysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
