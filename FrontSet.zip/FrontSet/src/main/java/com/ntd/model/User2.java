package com.ntd.model;

import lombok.Data;

@Data
public class User2 {
	private int id;
	private String name;
	private int age;
	public User2() {
		
	}
}
