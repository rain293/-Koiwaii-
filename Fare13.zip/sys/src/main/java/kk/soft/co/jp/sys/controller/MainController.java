package kk.soft.co.jp.sys.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import kk.soft.co.jp.sys.mapper.MessageInfoMstMapper;
import kk.soft.co.jp.sys.model.MessageInfoMstModel;
import kk.soft.co.jp.sys.service.MessageInfoMstService;
import lombok.extern.slf4j.Slf4j;

@RequestMapping("/")
@Slf4j
@Controller

public class MainController {

	@Autowired
	private MessageInfoMstMapper messageInfoMstMapper;

	@Resource
	MessageInfoMstService messageInfoMstService;

	/*
	 * time
	 */

	private static Map<Integer, String> selectYear = new LinkedHashMap<Integer, String>();
	private static Map<Integer, String> selectMonth = new LinkedHashMap<Integer, String>();
	private static Map<Integer, String> selectDay = new LinkedHashMap<Integer, String>();

	public static void setYearMonthDay() {
		for (int i = 1990; i <= 2023; i++) {
			selectYear.put(i, Integer.toString(i));
		}
		for (int i = 1; i <= 12; i++) {
			selectMonth.put(i, Integer.toString(i));
		}
		for (int i = 1; i <= 31; i++) {
			selectDay.put(i, Integer.toString(i));
		}
	}

	/*
	 * home
	 */

	@GetMapping
	public String getHome0(Model model) {
		model.addAttribute("msg", "ようこそ!");
		model.addAttribute("msg1", "ホームページへ");
		model.addAttribute("log_in_out", "ログイン");
		return "home";
	}

	@GetMapping("/home")
	public String getHome1(Model model) {
		model.addAttribute("msg", "ようこそ!");
		model.addAttribute("msg1", "ホームページへ");
		model.addAttribute("log_in_out", "ログイン");
		return "home";
	}

	@PostMapping("/home")
	public String postHome(MessageInfoMstModel messageInfoMstModel, Model model, HttpSession session) {
		MessageInfoMstModel newMessageInfoMstModel = messageInfoMstService.checkSignin(messageInfoMstModel);
		if (newMessageInfoMstModel == null) {
			model.addAttribute("msg", "メールまたはパスワードを正しく入力してください。");
			return "signin";

		} else if (messageInfoMstModel.getEmail().equals("admin1@gmail.com")) {

			return "redirect:/admin";

		} else {
			List<MessageInfoMstModel> listuser = messageInfoMstService.userInfo(messageInfoMstModel);
			session.setAttribute("email", messageInfoMstModel.getEmail());
			model.addAttribute("listuser", listuser);
			model.addAttribute("log_in_out", "ログアウト");
			String email = (String) session.getAttribute("email");
			System.out.println(email);
			return "user";
		}
	}

	/*
	 * signin
	 */

	@GetMapping("/signin")
	public String getSignin() {
		return "signin";
	}

	@PostMapping("/signin")
	public String postSignin() {
		return "signin";
	}

	/*
	 * signup
	 */

	@GetMapping("/signup")
	public String signup(Model model) {
		setYearMonthDay();
		model.addAttribute("years", selectYear);
		model.addAttribute("months", selectMonth);
		model.addAttribute("days", selectDay);
		return "signup";
	}

	/*
	 * check
	 */

	@PostMapping("/check")
	public String checking(MessageInfoMstModel messageInfoMstModel, Model model) {
		model.addAttribute("years", selectYear);
		model.addAttribute("months", selectMonth);
		model.addAttribute("days", selectDay);
		log.info("{}", messageInfoMstModel);
		if (isCorrect(messageInfoMstModel, model)) {
			return "check";
		} else {
			return "signup";
		}
	}

	@GetMapping("check")
	public String checked() {
		return "check";
	}

	private boolean isCorrect(MessageInfoMstModel messageInfoMstModel, Model model) {
		boolean isPrivacy = true;
		boolean isAllInput = true;
		boolean isEmailCorrect = true;
		boolean isPassCorrect = true;

		MessageInfoMstModel ok = messageInfoMstService.checkEmail(messageInfoMstModel);
		/*
		 * チェックボックスをチェックしてない場合
		 */
		if (messageInfoMstModel.getPrivacy() == null) {
			model.addAttribute("privacy_error", "利用規約を同意してください。");
			isPrivacy = false;
		}
		/*
		 * データが全部入力していない場合
		 * エラーメッセージが表示される
		 * 戻り値はfalseに返す
		 */
		if (messageInfoMstModel.getEmail() == "" || messageInfoMstModel.getPassword() == "") {
			model.addAttribute("all_error", "全部入力してください。");
			isAllInput = false;
		}
		/*
		 * アカウントはデータベース上に存在する場合
		 */
		if (ok != null) {
			model.addAttribute("email_error", "メールを正しく入力して下さい");
			isEmailCorrect = false;
		}
		/*
		 * パスワードは8以下の文字数しか入力していない場合
		 * エラーメッセージが表示される
		 * 戻り値はfalseに返す
		 */
		if (messageInfoMstModel.getPassword().length() < 6) {
			model.addAttribute("password_error", "パスワードは最低6文字数は必要です。");
			isPassCorrect = false;
		}
		/*
		 * アカウント名が全角文字を入力される場合
		 */
		if (checkzenhan(messageInfoMstModel.getEmail()) == false) {
			model.addAttribute("email_error", "メールを正しく入力して下さい");
			isEmailCorrect = false;
		}
		/*
		 * パスワードが全角文字を入力される場合
		 */
		if (checkzenhan(messageInfoMstModel.getPassword()) == false) {
			model.addAttribute("pass_error", "パスワードは半角英数字で入力してください。");
			isPassCorrect = false;
		}
		/*
		 * すべての条件は正しいの場合
		 * データを揃えてデータベースに挿入する
		 */
		if (isPrivacy && isPassCorrect && isEmailCorrect && isAllInput) {
			messageInfoMstService.insert(messageInfoMstModel);
			model.addAttribute("msg", "登録完了！");
			return true;
		} else
			return false;
	}

	/*
	 * ここで全角と半角を判定
	 * 半角だったらtrueに返す
	 * 全角だったらfalseに返す
	 */

	private boolean checkzenhan(String s) {
		char[] chars = s.toCharArray();
		boolean b = false;
		for (int i = 0; i < chars.length; i++) {
			if (String.valueOf(chars[i]).getBytes().length < 2) {
				//			             System.out.print("半");
				b = true;
			} else {
				//			             System.out.print("全");
				b = false;
			}
		}
		return b;
	}

	/*
	 * admin
	 */

	@GetMapping("/admin")
	public String getAdmin(Model model) {
		List<MessageInfoMstModel> messageInfoMstModel1 = messageInfoMstMapper.selectAdmin();
		model.addAttribute("messageInfoMstModel1", messageInfoMstModel1);
		model.addAttribute("log_in_out", "ログアウト");
		model.addAttribute("log_in_out1", "会員リスト");
		return "admin";
	}

	@PostMapping("/admin")
	public String postAdmin() {
		return "admin";
	}

	/*
	 * user
	 */

	@GetMapping("/user")
	public String mypage(Model model, HttpSession session) {
		/*List<MessageInfoMstModel> messageInfoMstModel2 = messageInfoMstMapper.selectUser();*/
		String email = (String) session.getAttribute("email");
		System.out.println(email);
		List<MessageInfoMstModel> listuser = messageInfoMstService.selectEmail(email);
		model.addAttribute("listuser", listuser);
		model.addAttribute("log_in_out", "ログアウト");
		return "user";
	}

	@PostMapping("/user")
	public String postUser() {
		return "user";
	}

	/*
	 * list
	 */

	@GetMapping("/list")
	public String list(Model model) {
		List<MessageInfoMstModel> messageInfoMstModel = messageInfoMstMapper.selectAll();
		model.addAttribute("messageInfoMstModel", messageInfoMstModel);
		return "list";
	}

	/*
	 * delete
	 */

	@GetMapping("/delete/{id}")
	public String getdelete(@PathVariable("id") int id, MessageInfoMstModel messageInfoMstModel, Model model) {
		List<MessageInfoMstModel> listuser = messageInfoMstService.back(messageInfoMstModel);
		model.addAttribute("listuser", listuser);
		return "delete";
	}

	@PostMapping("/delete/{id}")
	public String postdelete(@PathVariable("id") int id, MessageInfoMstModel messageInfoMstModel, Model model) {
		List<MessageInfoMstModel> listuser = messageInfoMstService.back(messageInfoMstModel);
		System.out.println(listuser);
		messageInfoMstService.delete(messageInfoMstModel);
		return "redirect:/list";
	}

	/*
	 * update
	 */

	@GetMapping("/update/{id}")
	public String getupdateid(@PathVariable("id") int id, Model model, MessageInfoMstModel messageInfoMstModel) {
		List<MessageInfoMstModel> listuser = messageInfoMstService.back(messageInfoMstModel);
		model.addAttribute("listuser", listuser);
		return "update";
	}

	@PostMapping("/update/{id}")
	public String update(@PathVariable("id") int id, Model model, MessageInfoMstModel messageInfoMstModel) {
		messageInfoMstService.update(messageInfoMstModel);
		System.out.println(messageInfoMstService.update(messageInfoMstModel));
		return "redirect:/list";
	}

	/*
	 * update1
	 */

	/*@GetMapping("/update1/{id}")
	public String getupdateid1(@PathVariable("id") int id, Model model, MessageInfoMstModel messageInfoMstModel) {
		List<MessageInfoMstModel> listuser = messageInfoMstService.back(messageInfoMstModel);
		model.addAttribute("listuser", listuser);
		return "update1";
	}
	
	@PostMapping("/update1/{id}")
	public String update1(@PathVariable("id") int id, Model model, MessageInfoMstModel messageInfoMstModel) {
		messageInfoMstService.update1(messageInfoMstModel);
		System.out.println(messageInfoMstService.update1(messageInfoMstModel));
		return "user";*/

	@GetMapping("/update1/{id}")
	public String getupdatd(@PathVariable("id") int id, Model model, MessageInfoMstModel messageInfoMstModel) {
		System.out.println(id);
		List<MessageInfoMstModel> listuser = messageInfoMstService.back1(id);
		model.addAttribute("listuser", listuser);
		return "update1";
	}

	@PostMapping("/update1/{id}")
	public String update1(@PathVariable("id") int id, MessageInfoMstModel messageInfoMstModel, Model model) {
		System.out.println(id);
		messageInfoMstService.update1(messageInfoMstModel);
		List<MessageInfoMstModel> listuser = messageInfoMstService.back1(id);
		model.addAttribute("listuser", listuser);
		model.addAttribute("log_in_out", "ログアウト");
		return "user";
	}

}
