package com.example.demo.controller;

import static org.assertj.core.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import com.example.demo.model.LoginUserModel;
import com.example.demo.model.NewUserModel;
import com.example.demo.model.UserUpdateModel;
import com.example.demo.service.LoginUserService;
import com.example.demo.service.NewUserService;
import com.example.demo.service.UserUpdateService;

@ExtendWith(MockitoExtension.class)

public class MainControllerTest4 {

	/*KanseiTest*/

	@Mock
	private NewUserService newUserService;

	@Mock
	private LoginUserService loginUserService;

	@Mock
	private HttpSession session;

	@Mock
	private UserUpdateService userUpdateService;

	@Mock
	private Model model;

	@Mock
	private BindingResult bindingResult;

	@Mock
	private NewUserModel newUserModel;

	@Mock
	private LoginUserModel loginUserModel;

	@Mock
	private UserUpdateModel userUpdateModel;

	@InjectMocks
	private MainController mainController;

	@BeforeEach
	/*毎テストを実行する前に@BeforeEachの設定を行う（メール、パスワードの準備）*/
	public void setup() {
		model = mock(Model.class);
		newUserModel = new NewUserModel();
		newUserModel.setEmail("z@z");
		newUserModel.setVisa("2029-04-30");
		newUserModel.setId(1);

		loginUserModel = new LoginUserModel();
		loginUserModel.setEmail("z@z");
		loginUserModel.setPassword("312");
	}

	//ログイン画面から新規登録
	@Test
	public void TestSignup() {
		/*MainControllerクラスのsignup()メソッドをテストするためのテストメソッド*/
		String result = mainController.signup();
		/*mainController の signup メソッドを呼び出して result 変数 に保存します*/
		assertEquals("signup", result);
		/*signup メソッドの結果 (result) を assertEquals メソッドと比較します。
		signup を返す場合、このテスト ケースは合格、それ以外は失敗と見なされます。*/
	}

	//ログイン画面に戻る
	@Test
	public void testBacklogin() {
		String result = mainController.backlogin();
		assertEquals("index", result);
	}

	//規登録画面(新しいユーザー)
	@Test
	public void testEntry_WithNewEmail() {
		
		/*新しい NewUserModel オブジェクトが作成されます。*/
		when(newUserService.search(newUserModel)).thenReturn(0);
		/*Mockito ライブラリから when を使用、 
		newUserService.search(newUserModel は 0 を返し
		(新しいユーザーが newUserModel と同じ電子メールを持っていないことを意味します)*/
		when(newUserService.insert(newUserModel)).thenReturn(1);
		/*newUserService.insert(newUserModel) は 1 を返します
		(新しいユーザーがシステムに追加されたことを意味します)。 */
		String result = mainController.entry(newUserModel, model);
		assertEquals("index", result);
		verify(model).addAttribute("name", "登録完了");
	}

	//規登録画面(登録されていない)
	@Test
	public void testEntry_WithExistingEmail() {
		NewUserModel newUserModel = new NewUserModel();
		when(newUserService.search(newUserModel)).thenReturn(1);
		String result = mainController.entry(newUserModel, model);
		assertEquals("signup", result);
		verify(model).addAttribute("id", "既にメールアドレスが登録されています。");
	}

	//ホーム画面
	@Test
	public void testHome() {
		List<NewUserModel> listuser = new ArrayList<>();
		listuser.add(newUserModel);
		/*listuser 変数 のリストを作成し、NewUserModel オブジェクト (newUserModel 変数) を追加します。*/
		when(newUserService.checkall(any(NewUserModel.class))).thenReturn(listuser);
		/*when() 関数を使用して newUserService オブジェクトの checkall() メソッドの動作を定義し、
		作成した NewUserModel オブジェクトのリストを返します。*/
		String result = mainController.home(model, newUserModel);
		assertEquals("home", result);
		verify(newUserService).checkall(any(NewUserModel.class));
		/*verify() 関数を使用してcheckall() メソッドが呼び出されたことを確認します。*/
		verify(model, times(1)).addAttribute(eq("daysBetweenList"), any(List.class));
		/*verify() 関数を使用して ListのdaysBetweenListが呼び出されたことを確認します。*/
	}

	@Test
	void testGetDelete() {
		NewUserModel newUserModel = new NewUserModel();
		// mock the selectupdate method of newUserService
		List<NewUserModel> listuser = new ArrayList<>();
		listuser.add(newUserModel);
		when(newUserService.selectupdate(newUserModel)).thenReturn(listuser);
		// call the getdelete method and check the returned view name and model attribute
		String result = mainController.getdelete(newUserModel.getId(), model, newUserModel);
		assertEquals("delete", result);
		verify(model, times(1)).addAttribute("listuser", listuser);
	}

	@Test
	void testPostDelete() {
		NewUserModel newUserModel = new NewUserModel();
		// call the delete method and check the returned view name and that the delete method of newUserService was called
		String result = mainController.delete(newUserModel.getId(), newUserModel);
		assertEquals("redirect:/user/home", result);
		verify(newUserService, times(1)).delete(newUserModel);
	}

	@Test
	void testGetUpdateId() {
		// Create objects of NewUserModel and listuser
		NewUserModel newUserModel = new NewUserModel();
		List<NewUserModel> listuser = new ArrayList<>();
		listuser.add(newUserModel);
		// Mock the selectupdate method of newUserService to return listuser when called with any argument
		when(newUserService.selectupdate(any(NewUserModel.class))).thenReturn(listuser);
		// Call the getupdateid() method of updateController with id=1 argument
		String result = mainController.getupdateid(1, model, newUserModel);
		// Check if the result is equal to the string "update"
		assertEquals("update", result);
		// Check if the selectupdate() method of newUserService has been called at least once with any argument
		verify(newUserService, atLeastOnce()).selectupdate(any(NewUserModel.class));
		// Check if the model.addAttribute() method has been called once with "listuser" and listuser arguments
		verify(model, times(1)).addAttribute(eq("listuser"), eq(listuser));
	}

	@Test
	void testUpdate() {
		// Create an object of NewUserModel
		NewUserModel newUserModel = new NewUserModel();
		// Block the update() method of newUserService from returning any value
		doAnswer(invocation -> null).when(newUserService).update(newUserModel);
		// Call the update() method of updateController with newUserModel and model arguments
		String result = mainController.update(newUserModel, model, bindingResult);
		// Check if the result is equal to the string "redirect:/user/home"
		assertEquals("redirect:/user/home", result);
		// Check if the update() method of newUserService has been called at least once with newUserModel argument
		verify(newUserService, atLeastOnce()).update(newUserModel);
	}

	@Test
	public void testSearchWithType() {
		List<NewUserModel> listUser = new ArrayList<>();
		when(newUserService.searchUser(any(String.class))).thenReturn(listUser);
		String result = mainController.search(null, "type", model);
		assertThat(result).isEqualTo("/home");
		verify(newUserService, times(1)).searchUser("type");
		verify(model, times(1)).addAttribute("listuser", listUser);
		verify(model, times(1)).addAttribute("daysBetweenList", new ArrayList<>());
	}

	@Test
	public void testSearchWithQuery() {
		List<NewUserModel> listUser = new ArrayList<>();
		when(newUserService.searchUser(any(String.class))).thenReturn(listUser);
		String result = mainController.search("query", null, model);
		assertThat(result).isEqualTo("/home");
		verify(newUserService, times(1)).searchUser("query");
		verify(model, times(1)).addAttribute("listuser", listUser);
		verify(model, times(1)).addAttribute("daysBetweenList", new ArrayList<>());
	}

	@Test
	public void testSearchWithoutParams() {
		List<NewUserModel> listUser = new ArrayList<>();
		String result = mainController.search(null, null, model);
		assertThat(result).isEqualTo("/home");
		verify(newUserService, times(0)).searchUser(any(String.class));
		verify(model, times(1)).addAttribute("listuser", listUser);
		verify(model, times(1)).addAttribute("daysBetweenList", new ArrayList<>());
	}

	@Test
	public void testGetUpdated() {
		int id = 1;
		List<UserUpdateModel> listuser = new ArrayList<>();
		listuser.add(userUpdateModel);
		when(userUpdateService.userupdate(id)).thenReturn(listuser);
		String result = mainController.getupdatd(id, model);
		assertEquals("userupdate", result);
		verify(userUpdateService).userupdate(id);
		verify(model, times(1)).addAttribute(eq("listuser"), any(List.class));
	}

	@Test
	public void testUpdate1() {
		int id = 1;
		LocalDate dbDate = LocalDate.now().plusDays(7);
		List<UserUpdateModel> listuser = new ArrayList<>();
		UserUpdateModel userUpdateModel = new UserUpdateModel();
		userUpdateModel.setVisa(dbDate.toString());
		listuser.add(userUpdateModel);
		when(userUpdateService.userupdate(id)).thenReturn(listuser);
		String result = mainController.update1(id, userUpdateModel, model);
		assertEquals("mypage", result);
		verify(userUpdateService).update1(userUpdateModel);
		verify(userUpdateService).userupdate(id);
		verify(model, times(1)).addAttribute(eq("listuser"), any(List.class));
		verify(model, times(1)).addAttribute(eq("daysBetween"), any(Long.class));
	}

	@Test
    public void testMypage() {
    	when(session.getAttribute(anyString())).thenReturn("test@example.com");
        // Mock data
        List<UserUpdateModel> listuser = new ArrayList<>();
        UserUpdateModel user = new UserUpdateModel();
        user.setVisa("2023-06-30");
        listuser.add(user);
        when(userUpdateService.selectusername(anyString())).thenReturn(listuser);        
        // Call the method
        String result = mainController.mypage(model, session);
        // Assertions
        assertThat(result).isEqualTo("mypage");
        verify(model).addAttribute("listuser", listuser);
        LocalDate today = LocalDate.now();
        LocalDate dbDate = LocalDate.parse(user.getVisa());
        long daysBetween = ChronoUnit.DAYS.between(today, dbDate);
        verify(model).addAttribute("daysBetween", daysBetween);
    }
}
