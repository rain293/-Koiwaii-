package kk.soft.co.jp.sys.service;

import java.util.List;

import kk.soft.co.jp.sys.model.MessageInfoMstModel;

public interface MessageInfoMstService {

	public Object selectAll();

	public MessageInfoMstModel checkEmail(MessageInfoMstModel messageInfoMstModel);

	public Object insert(MessageInfoMstModel messageInfoMstModel);

	public MessageInfoMstModel checkSignin(MessageInfoMstModel messageInfoMstModel);

	public int delete(MessageInfoMstModel messageInfoMstModel);

	public List<MessageInfoMstModel> back(MessageInfoMstModel messageInfoMstModel);

	public int update(MessageInfoMstModel messageInfoMstModel);
	
	public List<MessageInfoMstModel> back1(MessageInfoMstModel messageInfoMstModel);
	
	public int update1(MessageInfoMstModel messageInfoMstModel);

}
